const Discord = require("discord.js")
exports.run= async(client, message, args) => {

let csonline = message.guild.members.cache.filter(cs => cs.presence?.status === "online").size
let csdnd = message.guild.members.cache.filter(cs => cs.presence?.status === "dnd").size
let csidle = message.guild.members.cache.filter(cs => cs.presence?.status === "idle").size
let css = csonline+csidle+csdnd
let csoff = message.guild.memberCount-css
let cse = new Discord.EmbedBuilder()
.setTitle(message.guild.name+" Üye Durumları")
.setColor("#ff0000")
.setThumbnail(message.guild.iconURL({ dynamic: true }))
.addFields([
{ name: "Toplam Online", value: `\`${csonline}\`` },
{ name: "Toplam DND", value: `\`${csdnd}\`` },
{ name: "Toplam Idle", value: `\`${csidle}\`` },
{ name: "Toplam Offline", value: `\`${csoff}\`` }, 
{ name: "Toplam Durum", value: `\`${css}\`` }, 
{ name: "Toplam Üye", value: `\`${message.guild.memberCount}\`` }
])
.setTimestamp()
message.channel.send({embeds: [cse]})
}

exports.conf = {
aliases: []
}

exports.help = {
name: "kontrol"
}