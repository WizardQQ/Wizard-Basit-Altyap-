const { EmbedBuilder, PermissionsBitField } = require("discord.js");

exports.run = async (client, message, args) => {

    if(!message.member.permissions.has(PermissionsBitField.Flags.BanMembers)) {
        return message.channel.send({ embeds: [{ description: "Bu komutu kullanmaya yetkin yetmiyor\n Bu komutu kullanmak için `Üyeleri Engelle` iznine sahip olman **gerekiyor**." }] })
    }

    const user = message.mentions.users.first();

    if(!user) {
       return message.channel.send({ embeds: [{ description: "Eksik Komut birini etiketlemen gerekiyor.\n Örnek: `s!ban @user`" }] })
    }

    message.guild.members.ban(user).then(() => message.channel.send({ embeds: [{ description: "Kullanıcı Sunucudan Yasaklandı!" }] })).catch(() => message.channel.send({ embeds: [{ description: "❌ Bu kullanıcıyı banlıyamıyorum **rolümü** onun **üstüne** taşıman gerek! " }] }))
    

};
exports.conf = {
  aliases: []
};

exports.help = {
  name: "ban"
};