const { EmbedBuilder, PermissionsBitField } = require("discord.js");
const db = require("croxydb");

exports.run = async (client, message, args) => {

    const value = args[0];
    const hgbb = db.fetch(`hgbb_${message.guild.id}`);

    if(!message.member.permissions.has(PermissionsBitField.Flags.ManageGuild)) {
        return message.channel.send({ embeds: [{ description: "Bu komutu kullanmak için `Sunucuyu Yönet` iznine sahip olman **gerek.**" }] })
    }

    if(!value) {
        return message.channel.send({ embeds: [{ description: "Bir değer girmeniz gerekiyor. (`ayarla`/`sıfırla`)" }] })
    }

    if(value.includes("ayarla")) {
        if(hgbb) return message.channel.send({ embeds: [{ description: "Sistem zaten **aktif.**" }] })

        const channel = message.mentions.channels.first()
        if(!channel) return message.channel.send({ embeds: [{ description: ":x: **|** Bir kanal etiketlemeniz **gerekiyor.**" }] })

        db.set(`hgbb_${message.guild.id}`, { kanal: channel.id })
        return message.channel.send({ embeds: [{ description: "Giriş çıkış sistemi aktif hale getirildi sistem artık **çalışıyor.**" }] })

    } else if(value.includes("sıfırla")) {
        if(!hgbb) return message.channel.send({ embeds: [{ description: ":x: **|** Sistem zaten de-aktif." }] })

        db.delete(`hgbb_${message.guild.id}`)
        return message.channel.send({ embeds: [{ description: " Giriş çıkış sistemi pasif hale getirildi sistem artık **çalışmıyor.**" }] })
    }

};
exports.conf = {
  aliases: []
};

exports.help = {
  name: "giriş-çıkış"
};