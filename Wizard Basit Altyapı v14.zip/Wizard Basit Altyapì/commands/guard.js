const { EmbedBuilder, PermissionsBitField } = require("discord.js");
const db = require("croxydb");

exports.run = async (client, message, args) => {

    if(!message.member.permissions.has(PermissionsBitField.Flags.Administrator)) {
        return message.channel.send({ embeds: [{ description: ":x: **|** Bu komutu kullanmak için `Yönetici` iznine sahip olman gerek." }] })
    }

    const value = args[0]
    if(!value) {
        return message.channel.send({ embeds: [{ description: ":x: **|** Bir değer girmeniz gerekiyor. (`ayarla`/`sıfırla`)" }] })
    }

    const guard = db.fetch(`koruma_${message.guild.id}`)

    if(value.includes("ayarla")) {
        if(guard) {
            return message.channel.send({ embeds: [{ description: "Koruma sistemi zaten **aktif.**" }] })
        }

        const channel = message.mentions.channels.first()
        if(!channel) return message.channel.send({ embeds: [{ description: " Bir kanal etiketlemeniz **gerekiyor.**" }] })

        db.set(`koruma_${message.guild.id}`, { kanal: channel.id })
        return message.channel.send({ embeds: [{ description: "Koruma sistemi aktif edildi, sistem artık **çalışıyor.**" }] })

    } else if(value.includes("sıfırla")) {
        if(guard) {
            return message.channel.send({ embeds: [{ description: "Koruma sistemi zaten **aktif.**" }] })
        }

        db.delete(`koruma_${message.guild.id}`)
        return message.channel.send({ embeds: [{ description: " Koruma sistemi pasif hale getirildi, sistem artık **çalışmıyor.**" }] })

    }

};
exports.conf = {
  aliases: []
};

exports.help = {
  name: "koruma"
};