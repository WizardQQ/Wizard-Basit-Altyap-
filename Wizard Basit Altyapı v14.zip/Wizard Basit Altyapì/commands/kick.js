const { EmbedBuilder, PermissionsBitField } = require("discord.js");

exports.run = async (client, message, args) => {

    if(!message.member.permissions.has(PermissionsBitField.Flags.KickMembers)) {
        return message.channel.send({ embeds: [{ description: ":x: **|** Bu komutu kullanmak için `Üyeleri Yasakla` iznine sahip olman gerek." }] })
    }
    
    const user = message.mentions.members.first();

    if(!user) {
        return message.channel.send({ embeds: [{ description: ":x: **|** Birini etiketlemen gerekiyor." }] })
    }

    user.kick();
    return message.channel.send({ embeds: [{ description: ":white_check_mark: **|** Kullanıcı başarıyla sunucudan atıldı." }] })

};
exports.conf = {
  aliases: []
};

exports.help = {
  name: "kick"
};
