const { EmbedBuilder } = require("discord.js");
const db = require("croxydb");

exports.run = async (client, message, args) => {

    const embed = new EmbedBuilder()
    .setDescription("Pingim: **"+client.ws.ping+"ms**")

    return message.channel.send({embeds : [embed]});

};
exports.conf = {
  aliases: []
};

exports.help = {
  name: "ping"
};