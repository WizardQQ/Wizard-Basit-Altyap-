const { EmbedBuilder, PermissionsBitField } = require("discord.js");
const db = require("croxydb");

exports.run = async (client, message, args) => {

    if(!message.member.permissions.has(PermissionsBitField.Flags.ManageMessages)) {
        return message.channel.send({ embeds: [{ description: "Bu komutu kullanmak için `Mesajları Yönet` iznine sahip olman **gerek.**" }] })
    }

    const limit = args[0]
    if(!limit) {
        return message.channel.send({ embeds: [{ description: "`1-100` arasında bir sayı giriniz." }] })
    }

    if(isNaN(limit)) {
        return message.channel.send({ embeds: [{ description: "`1-100` arasında bir sayı giriniz." }] })
    }

    if(Number(limit) > 100) {
        return message.channel.send({ embeds: [{ description: "`1-100` arasında bir sayı giriniz." }] })
    }

    if(Number(limit) < 1) {
        return message.channel.send({ embeds: [{ description: "Lütfen `1-100` arasında bir sayı giriniz." }] })
    }

    message.channel.bulkDelete(Number(limit), true).then(() => {
        setTimeout(() => {
            return message.channel.send({ embeds: [{ description: "`"+limit+"` mesaj silindi." }] })
      }, 1000)
      })


};
exports.conf = {
  aliases: []
};

exports.help = {
  name: "sil"
};
