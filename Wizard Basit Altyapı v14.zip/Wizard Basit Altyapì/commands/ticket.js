const { EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle, PermissionsBitField } = require("discord.js");
const db = require("croxydb");


exports.run = async (client, message, args) => {

    if(!message.member.permissions.has(PermissionsBitField.Flags.ManageGuild)) {
        return message.channel.send({ embeds: [{ description: "Bu komutu kullanmak için `Sunucuyu Yönet` iznine sahip **olman gerek.**" }] })
    }

    const ticket = db.fetch(`ticket_${message.guild.id}`);
    const value = args[0];
    if(!value) {
        return message.channel.send({ embeds: [{ description: "Bir değer girmeniz gerekiyor. (`ayarla`/`sıfırla`)" }] })
    }

    if(value.includes("ayarla")) {
        if(ticket) {
            return message.channel.send({ embeds: [{ description: "Sistem zaten aktif durumda" }] })
        }

        const embed = new EmbedBuilder()
        .setColor("#f2cf1f")
        .setTitle("Destek Sistemi")
        .setDescription("・ Destek açmak için aşağıdaki butona tıklayabilirsin\n・ Eğer yardıma ihtiyacın varsa, bize bir buton uzaktasın.")
        .setThumbnail(message.guild.iconURL() || null)
        .setFooter({ text: 'Wizard Basit Altyapı', iconURL: 'https://cdn.discordapp.com/attachments/1056528610590208042/1079372707247956068/wallpaper_15783783425e142466e5db7.jpg' });

        const row = new ActionRowBuilder()
        .addComponents(
            new ButtonBuilder()
            .setCustomId("destekac")
            .setEmoji("📩")
            .setLabel("Destek Aç")
            .setStyle(ButtonStyle.Secondary)
        )

        db.set(`ticket_${message.guild.id}`, true)
        return message.channel.send({ embeds: [embed], components: [row] })

    } else if(value.includes("sıfırla")) {
        if(!ticket) {
            return message.channel.send({ embeds: [{ description: "Sistem zaten pasif durumda **çakışmıyor.**" }] })
        }

        db.delete(`ticket_${message.guild.id}`)
        return message.channel.send({ embeds: [{ description: `Destek sistemi sıfırlandı.` }] })

    }

};
exports.conf = {
  aliases: []
};

exports.help = {
  name: "ticket"
};
