module.exports = {
    token: "Token buriya gir", 
    prefix: ".",
}