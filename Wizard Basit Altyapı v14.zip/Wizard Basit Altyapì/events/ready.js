const client = require("../index");
const { Collection } = require("discord.js")
const fs = require("fs")

client.on("ready", () => {

setInterval(async () => {

    const activities = ["Wizard", "Basit Altyapı"]
    const lourityRandom = activities[
        Math.floor(Math.random() * activities.length)];
    client.user.setActivity(`${lourityRandom}`)
    }, 16000);

    console.log(`Bot Aktif Edildi!`)


client.commands = new Collection();
client.aliases = new Collection();
fs.readdir("./commands/", (err, files) => {
if (err) console.error(err);

files.forEach(f => {
let props = require(`../commands/${f}`);

    
client.commands.set(props.help.name, props);
props.conf.aliases.forEach(alias => {
client.aliases.set(alias, props.help.name);
});
});
});

});