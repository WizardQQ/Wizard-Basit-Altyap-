const { Client, GatewayIntentBits, Partials, ActionRowBuilder, ButtonBuilder, ButtonStyle, EmbedBuilder, ChannelType, PermissionsBitField, AuditLogEvent } = require("discord.js");
const config = require("./config.js");
const db = require("croxydb");

const client = new Client({
  partials: [
    Partials.Message, // for message
    Partials.Channel, // for text channel
    Partials.GuildMember, // for guild member
    Partials.Reaction, // for message reaction
    Partials.GuildScheduledEvent, // for guild events
    Partials.User, // for discord user
    Partials.ThreadMember, // for thread member
  ],
  intents: [
    GatewayIntentBits.Guilds, // for guild related things
    GatewayIntentBits.GuildMembers, // for guild members related things
    GatewayIntentBits.GuildBans, // for manage guild bans
    GatewayIntentBits.GuildEmojisAndStickers, // for manage emojis and stickers
    GatewayIntentBits.GuildIntegrations, // for discord Integrations
    GatewayIntentBits.GuildWebhooks, // for discord webhooks
    GatewayIntentBits.GuildInvites, // for guild invite managing
    GatewayIntentBits.GuildVoiceStates, // for voice related things
    GatewayIntentBits.GuildPresences, // for user presence things
    GatewayIntentBits.GuildMessages, // for guild messages things
    GatewayIntentBits.GuildMessageReactions, // for message reactions things
    GatewayIntentBits.GuildMessageTyping, // for message typing things
    GatewayIntentBits.DirectMessages, // for dm messages
    GatewayIntentBits.DirectMessageReactions, // for dm message reaction
    GatewayIntentBits.DirectMessageTyping, // for dm message typinh
    GatewayIntentBits.MessageContent, // enable if you need message content things
  ],
});

module.exports = client;

require("./events/message.js")
require("./events/ready.js")

client.on("interactionCreate", async(interaction) => {
  if(interaction.isButton()) {
    if(interaction.customId === "destekac") {

      const id = interaction.user.id.slice(0, 4)

      const isChannel = await interaction.guild.channels.cache.find(ch => ch.name === `destek-${id}`)
        if(isChannel) {
          return interaction.reply({ embeds: [
        new EmbedBuilder().setColor(0x2F3136).setDescription(`:x: **|** Destek kanalın daha önceden aktif edilmiş. *[Daha fazla bilgi](https://discordapp.com/channels/${interaction.guild.id}/${isChannel.id})*`)
      ], ephemeral: true }) 
        }

        const embed = new EmbedBuilder()
        .setColor(0x2F3136)
        .setAuthor({ name: `${interaction.user.tag}`, iconURL: `${interaction.user.displayAvatarURL()} ` })
        .setDescription(`Merhaba ${interaction.user.username}, bilgilerini teslim aldık ve gerekli bilgileri inceliyoruz. En kısa zamanda sana dönüş yapacağız!`)
        .setTimestamp()
        .setFooter({ text: `${interaction.user.tag} tarafından açıldı.`, iconURL: `${interaction.user.displayAvatarURL()} ` })

        const row = new ActionRowBuilder()
        .addComponents(
            new ButtonBuilder()
            .setCustomId("kapat")
            .setLabel("Desteği Kapat")
            .setStyle(ButtonStyle.Secondary)
        )

        const chnl = await interaction.guild.channels.create({
          name: `destek-${interaction.user.id.slice(0, 4)}`,
          type: ChannelType.GuildText,
          permissionOverwrites: [
            {
              id: interaction.guild.id,
              deny: [PermissionsBitField.Flags.ViewChannel],
            },
            {
              id: interaction.user.id,
              allow: [PermissionsBitField.Flags.ViewChannel],
            },
          ],
        });

        const msg = await chnl.send({ content: `<@${interaction.user.id}>`, embeds: [embed], components: [row] })
        msg.pin()

        interaction.reply({ content: `Destek kanalın başarıyla aktif edildi.`, ephemeral: true })
    }

    if(interaction.customId === "kapat") {
      interaction.channel.delete()
    }
  }
});

client.on("roleDelete", async(role) => {
  const guard = db.fetch(`koruma_${role.guild.id}`);
  
  if(guard) {
    const channel = await role.guild.channels.cache.find(x => x.id === guard.kanal);

    const fetchedLogs = await role.guild.fetchAuditLogs({
      limit: 1,
      type: AuditLogEvent.RoleDelete
    });

    const deletionLog = fetchedLogs.entries.first();

    const { executor, target } = deletionLog;

    const member = await role.guild.members.cache.get(executor.id);

    await role.guild.members.ban(member.user, {
      reason: "Rol silmek"
    });

    channel.send({ description: `<@${executor.id}> bir rol sildi ve bende onu başarıyla banladım.` })
  }
});

client.on("channelDelete", async(role) => {
  const guard = db.fetch(`koruma_${role.guild.id}`);
  
  if(guard) {
    const channel = await role.guild.channels.cache.find(x => x.id === guard.kanal);

    const fetchedLogs = await role.guild.fetchAuditLogs({
      limit: 1,
      type: AuditLogEvent.ChannelDelete
    });

    const deletionLog = fetchedLogs.entries.first();

    const { executor, target } = deletionLog;

    const member = await role.guild.members.cache.get(executor.id);

    await role.guild.members.ban(member.user, {
      reason: "Kanal silmek"
    });

    channel.send({ description: `<@${executor.id}> bir kanal sildi ve bende onu başarıyla banladım.` })
  }
});

client.on('interactionCreate', async (interaction) => {
	if (!interaction.isButton()) return;
  let message = await interaction.channel.messages.fetch(interaction.message.id)
  if(interaction.customId == "evet") {
const db = require("croxydb")
db.push(`evet_${interaction.message.id}`, interaction.user.id)
interaction.reply({content: "Başarıyla Oyunu **Evet** Olarak Verdin!", ephemeral: true})

const evet = db.get(`evet_${interaction.message.id}`).length;
const hayir = db.get(`hayir_${interaction.message.id}`).length;
const aciklama = db.get(`oylama_${interaction.message.id}`)
const embed = new EmbedBuilder()
.setTitle("Wizard basit bot altyapı - Oylama Sistemi!")
.setDescription(`Oylama: **${aciklama}**\n\nEvet: **${evet}**\n\nHayır: **${hayir}**`)
.setColor("#ff0000")
await message.edit({embeds: [embed]})
  }
});
client.on('interactionCreate', async (interaction) => {
	if (!interaction.isButton()) return;
  let message = await interaction.channel.messages.fetch(interaction.message.id)
  if(interaction.customId == "hayır") {
const db = require("croxydb")
db.push(`hayir_${interaction.message.id}`, interaction.user.id)
interaction.reply({content: "Başarıyla Oyunu **Hayır** Olarak Verdin!", ephemeral: true})

const evet = db.get(`evet_${interaction.message.id}`).length;
const hayir = db.get(`hayir_${interaction.message.id}`).length;
const aciklama = db.get(`oylama_${interaction.message.id}`)
const embed = new EmbedBuilder()
.setTitle("Special - Oylama Sistemi!")
.setDescription(`Oylama: **${aciklama}**\n\nEvet: **${evet}**\n\nHayır: **${hayir}**`)
.setColor("#ff0000")
await message.edit({embeds: [embed]})
  }
});

client.on("guildBanAdd", async(role) => {
  const guard = db.fetch(`koruma_${role.guild.id}`);
  
  if(guard) {
    const channel = await role.guild.channels.cache.find(x => x.id === guard.kanal);

    const fetchedLogs = await role.guild.fetchAuditLogs({
      limit: 1,
      type: AuditLogEvent.MemberBanAdd
    });

    const deletionLog = fetchedLogs.entries.first();

    const { executor, target } = deletionLog;

    const member = await role.guild.members.cache.get(executor.id);

    await role.guild.members.ban(member.user, {
      reason: "birini banlamak"
    });

    channel.send({ description: `<@${executor.id}> birini banladı ve bende onu başarıyla banladım.` })
  }
});

client.login(config.token || process.env.TOKEN).catch(e => {
console.error("Projenize Girdiğiniz Bot Simgesi Hatalı Veya Botunuzun NİYETİ KAPALI!")
})


const express = require("express");
const app = express();
const http = require("http");
app.get("/", (request, response) => {
  response.sendStatus(200);
});
app.listen(process.env.PORT);
